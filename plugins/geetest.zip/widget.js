// 极验行为验证 v4 前端渲染
// 文档: https://docs.geetest.com/gt4/apirefer/api/web

window.__novaix_captcha_init = function(container, config, callbacks) {
    var script = document.createElement("script");
    script.src = "https://static.geetest.com/v4/gt4.js";
    script.onload = function() {
        if (typeof initGeetest4 !== "function") {
            callbacks.onError("极验 SDK 加载异常");
            return;
        }
        var product = config.product || "bind";
        var btn = null;

        initGeetest4({
            captchaId: config.captcha_id,
            product: product
        }, function(captchaObj) {
            window.__novaix_geetest_obj = captchaObj;

            captchaObj.onSuccess(function() {
                var result = captchaObj.getValidate();
                if (!result) {
                    callbacks.onError("验证结果获取失败");
                    return;
                }
                if (btn) {
                    btn.textContent = "✓ 验证通过";
                    btn.style.borderColor = "#10b981";
                    btn.style.color = "#059669";
                    btn.style.cursor = "default";
                    btn.onclick = null;
                }
                callbacks.onSuccess(JSON.stringify({
                    lot_number: result.lot_number,
                    captcha_output: result.captcha_output,
                    pass_token: result.pass_token,
                    gen_time: result.gen_time
                }));
            });

            captchaObj.onFail(function() {
                callbacks.onError("验证失败，请重试");
            });

            captchaObj.onError(function(err) {
                callbacks.onError(err && err.msg ? err.msg : "验证服务异常");
            });

            captchaObj.onClose(function() {
                callbacks.onExpired();
            });

            if (product === "bind") {
                container.innerHTML = "";
                btn = document.createElement("button");
                btn.type = "button";
                btn.textContent = "点击进行人机验证";
                btn.style.cssText = "width:100%;padding:10px 16px;border:1px solid #d1d5db;border-radius:6px;background:#f9fafb;cursor:pointer;font-size:14px;color:#374151;transition:border-color 0.15s";
                btn.onmouseenter = function() { btn.style.borderColor = "#9ca3af"; };
                btn.onmouseleave = function() { btn.style.borderColor = "#d1d5db"; };
                btn.onclick = function() { captchaObj.showCaptcha(); };
                container.appendChild(btn);
            } else {
                captchaObj.appendTo(container);
            }
        });
    };
    script.onerror = function() {
        callbacks.onError("极验 SDK 加载失败");
    };
    document.head.appendChild(script);
};

window.__novaix_captcha_destroy = function() {
    if (window.__novaix_geetest_obj) {
        try { window.__novaix_geetest_obj.destroy(); } catch(e) {}
        delete window.__novaix_geetest_obj;
    }
};
